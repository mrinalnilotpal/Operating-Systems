#include<bits/stdc++.h>
#include<cmath>
#include<vector>
#include<iostream>
#define long long int lli

int FCFS(int n, int arrv[], int exectm[]);
int SJF(int n, int arrv[], int exectm[]);
int priorsch(int n, int arrv[], int exectm[]);
int roundrobin(int n, int arrv[], int exectm[]);

using namespace std;

int main()
{
    int numprocess, i,j;
    cout<<"Enter Number of Processes: ";
    cin>>numprocess;

    int exetim[numprocess];
    int arrvtim[numprocess];


    cout <<" Enter the execution time respectively : ";
    for(i=1; i<=numprocess; i++)
    {
        cin>> exetim[i];
    }

      cout <<" Enter the arrival time respectively (will be in sorted order) : ";
        for(j=1; j<=numprocess; j++)
    {
        cin >> arrvtim[j];
    }

    cout<< "Enter the Algorithm you want to use:"<<"\n";
    cout<< "1. First Come First Serve Scheduling"<<"\n";
    cout<< "2. Shortest Job First Scheduling"<<"\n";
    cout<< "3. Priority Scheduling "<<"\n";
    cout<< "4. Round Robin Scheduling "<<"\n";

    int ch;
      cin>>ch;

      switch(ch){
  case 1: FCFS(numprocess,arrvtim,exetim);
  // case 2: SJF( numprocess,  arrvtim, exetim);
    //case 3: priorsch( numprocess,  arrvtim,  exetim);
     //case 4: roundrobin( numprocess, arrvtim, exetim);

    }

}
int FCFS(int n, int arrv[], int exectm[])
{
   int i, waittm[n+1], turnaround[n],ATAT;

   for(i=1; i<=n; i++)
   {
       turnaround[i] = accumulate(exectm,exectm+i,0);
   }

      for(i=1; i<=n; i++)
   {
      cout<<turnaround[i]<<" ";
   }
}

